export interface InquiryType {
  consumerEmail: string;
  providerEmail: string;
  inquire: string;
  serviceTitle: string;
}
