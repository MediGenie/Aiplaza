export interface UploadedFile {
  size: number;
  key: string;
  path: string;
  mimetype: string;
  originalName: string;
}
